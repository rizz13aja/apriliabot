
/* Thanks To
> Rizz ( Base / Creator )
> Kumpulan Kaum Rebahan ( Gc Owner )
> Admin kkr ( Aulia, Queenva, Arti )
> Nara ( Name creator & Backsound dubbing )
> All Team DarkSide1337 ( Fitur Creator & Team Owner )

[ Rizz13 From Always Compact ] */